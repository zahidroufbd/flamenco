from BasicTypeAttr import BasicTypeAttr


class LongAttr(BasicTypeAttr):
	pass
