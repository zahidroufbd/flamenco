from BasicTypeAttr import BasicTypeAttr


class StringAttr(BasicTypeAttr):
	pass
